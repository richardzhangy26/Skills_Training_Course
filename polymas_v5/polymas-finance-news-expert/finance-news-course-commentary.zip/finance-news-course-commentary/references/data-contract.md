# 数据契约

本文件是 `finance-news-course-commentary` 的唯一字段契约。调用方在进入本 Skill 前已经确定一名学生和一门可访问课程；Skill 本身不持久化这些身份信息。

## 输入

normalizer 的输入为一个 JSON 对象：

```json
{
  "course": {
    "course_id": "课程标识",
    "course_name": "课程名称"
  },
  "retrieved_at": "2026-08-22T01:02:03+08:00",
  "course_evidence_available": true,
  "candidates": []
}
```

顶层字段均为 normalizer 输入：

| 字段 | 约束 |
|---|---|
| `course` | 含可识别课程名称的对象 |
| `retrieved_at` | 必填，带时区的 ISO8601 检索时间；必须在公开网检索开始时记录，不能用新闻发布时间替代 |
| `course_evidence_available` | 必填布尔值；仅当学生教学计划/学习资源能提供所选课程的可核验知识点和摘录时为 `true` |
| `candidates` | 数组；即使 `course_evidence_available` 为 `false` 也必须提供（通常为空数组） |

`course` 必须含可识别的课程名称。每个 `candidates` 元素必须包含：

| 字段 | 约束 |
|---|---|
| `title` | 新闻标题，非空字符串 |
| `url` | 可公开访问的 `http` 或 `https` URL |
| `source` | 来源名称 |
| `source_tier` | 必填来源分层；由平台通用工具返回候选后，编排方按 `source-policy.md` 在 normalizer 前赋值，允许值和映射见下表 |
| `published_at` | 带时区的 ISO8601 发布时间 |
| `fact_summary` | 与来源可核对的事实摘要 |
| `theory_analysis` | 基于已取得课程依据的学习分析，不含投资建议；只能在 citations 完整后、normalizer 前生成 |
| `discussion_question` | 供学生讨论的开放问题，不引导交易；只能在 citations 完整后、normalizer 前生成 |
| `theory_citations` | 非空数组，每项见下表 |

每条 `theory_citations` 必须同时包含非空的 `course_name`、`knowledge_point`、`resource_title`、`excerpt`。其中 `course_name` 必须等于所选课程；缺失、跨课程或不可核验都视为无课程证据。

### `source_tier` 枚举与映射

`source_tier` 是候选的必填输入字段。编排方必须依据来源策略赋值，normalizer 随后强制校验并将它映射为输出 `source_level`：

| `source_tier` 允许值 | 输出 `source_level` | 含义 |
|---|---:|---|
| `official`、`primary`、`regulator`、`government`、`exchange`、`company_announcement` | 1 | 官方/一级来源 |
| `authoritative_media`、`media` | 2 | 权威财经媒体/二级来源 |
| `other` | 3 | 三级公开线索；normalizer 强制拒绝并记录 `untrusted_source` |

`source_level` 是输出，不是调用方输入。调用方不得以 `source_level` 替代 `source_tier`，也不得根据来源名称自行写入输出等级。

`retrieved_at` 属于 normalizer 的输入或输出字段：它作为顶层必填输入，经 ISO8601 解析并规范化后回传到输出。调用方在公开网检索开始时写入该值；展示模板只读取 normalizer 输出中的 `retrieved_at`。

## normalizer 调用与输出

```bash
python3 scripts/normalize_candidates.py \
  --input candidates.json \
  --since 2026-08-22T00:00:00+08:00 \
  --until 2026-08-22T23:59:59+08:00 \
  --edition-date 2026-08-22 \
  --max-items 3
```

stdout 只输出一个 JSON 对象；成功对象包含 `status`、`status_origin`、`edition_id`、`course`、`retrieved_at`、`course_evidence_available`、`items`、`rejected`。`items` 是可以展示的候选，每项保留输入字段、`source_level` 与 `item_id`；`rejected` 记录未采用候选及原因。

| `status` | 含义与后续动作 |
|---|---|
| `ready` | `status_origin: normalizer`；使用 `items` 生成简报 |
| `no_eligible_candidates` | `status_origin: normalizer`；如实报告本期没有合格公开候选 |
| `skipped_no_course_evidence` | 不生成通用点评；见下列唯一状态来源 |

| 条件 | `status` | `status_origin` |
|---|---|---|
| `course_evidence_available: false` | `skipped_no_course_evidence` | `precheck` |
| 所有候选均因 `missing_course_evidence` 或 `course_mismatch` 被拒绝 | `skipped_no_course_evidence` | `candidate_filter` |
| 其他路径 | 由 normalizer 正常判定 | `normalizer` |

所有路径都必须调用 normalizer。调用方不得直接构造状态或 `status_origin`；前置证据不可用时，仍传入 `course_evidence_available: false` 及 `candidates` 数组，由 normalizer 返回 `precheck`。

`edition_id` 为 `FYYYYMMDD`。每个入选条目的 `item_id` 由排名后的位置确定，格式为 `FYYYYMMDD-01`、`FYYYYMMDD-02`、`FYYYYMMDD-03`；同一输入、时间窗、日期和上限必须得到相同 ID。不得自行改写 normalizer 的排序、去重或拒绝原因。

normalizer 强制拒绝三级来源：它先强制校验 `source_tier`，映射后的 `source_level` 为 3 的候选进入 `rejected`，原因为 `untrusted_source`，不得出现在 `items`。一级来源优先于二级来源，再由发布时间、标题和 URL 作确定性排序；三级来源不会成为可展示候选。

## 与订阅工作流的边界

订阅记录由专家维护。一份订阅只绑定一名学生和一门课程，其稳定任务键为 `finance-news:{schoolId}:{userId}:{courseId}`，不得包含会话 ID。`target_session_id` 是投递前重新校验的目标，不是任务键的一部分。Skill 不创建或保存上述记录，也不使用真实学生 ID、会话 ID、Cookie 或 Token。

## 展示映射

`items` 的 `fact_summary` 映射到新闻事实；`theory_citations` 映射到课程依据；`theory_analysis` 映射到理论分析；`discussion_question` 映射到讨论问题。不得在任何映射中删除来源 URL、发布时间或课程原文摘录。
